<?php 
    // if(isset($_SESSION['user'])){
    //     header('location: ../site/tai-khoan/dang-nhap.php');
    // }else {
    //     print_r($_SESSION['user']);
        // if($_SESSION['user']['vai_tro'] == 1){
           header('location: trang-chinh/index.php');
        // }else {
        //     echo "<script>
        //             alert('Chỉ tài khoản thành viên mới có thể đăng nhập vào trang quản trị!');
        //         </script>";
        //         header('location: ../site/tai-khoan/dang-nhap.php');
        // }
    
   
?>