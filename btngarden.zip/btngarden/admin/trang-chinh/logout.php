<?php 
    session_unset();
    header('location: ../../site/tai-khoan/dang-nhap.php');
?>